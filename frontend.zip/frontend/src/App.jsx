// import React from "react";
// import Spline from "./components/spline";

// export default function Home() {
//   return <Spline />;
// }









import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./components/hero";
import Spline from "./components/spline";

export default function App() {
  return (
    <Router>
      <Routes>
        {/* Home route */}
        <Route path="/" element={<Home />} />
        <Route path="/spline" element={<Spline />} />
      </Routes>
    </Router>
  );
}
